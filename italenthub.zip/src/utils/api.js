export const API_URL = "http://153.156.216.42:5003/eaas/";

export const API_HEADERS = {
    "Content-Type" : "application/json"
}