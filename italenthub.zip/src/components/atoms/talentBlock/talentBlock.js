import React from 'react';
import PropTypes from 'prop-types';

class TalentBlock extends React.Component {
    state = {
        
    }

    // static getDerivedStateFromProps(nextProps, prevState) {
    //     return {
    //              active: nextProps.active,
    //              links: nextProps.links
    //            };
    //  }

    render() {
        return (
            <div>

            </div>
        )
    }
}

TalentBlock.propTypes = {

}

TalentBlock.defaultProps = {

}

export default TalentBlock;